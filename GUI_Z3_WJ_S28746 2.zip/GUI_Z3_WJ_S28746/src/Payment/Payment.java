package Payment;

public enum Payment {
    CARD, TRANSFER
}