package VehicleType;

public enum VehicleType {
    CAR, DELIVERY, VINTAGE, FREE
}
